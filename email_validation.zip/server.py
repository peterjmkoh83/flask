from flask import Flask, render_template, flash, redirect, session, request
from mysqlconnection import connectToMySQL
import re

app = Flask(__name__)
app.secret_key = "safe"

EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

@app.route("/")
def index():
     return render_template("index.html")

@app.route("/process", methods=["POST"])
def process():
     if not EMAIL_REGEX.match(request.form["email"]):
          flash("Invalid email address!")
          return redirect("/")
     else: 
          flash("You're successfully added!")
     
     mysql = connectToMySQL("validation")
   
     queryToInsertEmail = "INSERT INTO emails(email, created_at, updated_at) VALUES (%(em)s, NOW(), NOW());"
     data = {
          "em": request.form["email"]
     }
     session["email_id"] = mysql.query_db(queryToInsertEmail, data)
     print(session["email_id"])

     return redirect("/success")

@app.route("/success")
def success():
     mysql = connectToMySQL("validation")
     queryToGetOneRow = "SELECT * FROM emails WHERE id=%(id)s;"
     data = {
          "id": session["email_id"]
     }
     showOneId = mysql.query_db(queryToGetOneRow, data)
     print(showOneId)

     return render_template("success.html", oneRow = showOneId)
     

if __name__ == "__main__":
     app.run(debug=True)