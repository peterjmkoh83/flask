from flask import Flask, render_template, redirect, session, flash, request
from mysqlconnection import connectToMySQL


app = Flask(__name__)
app.secret_key = "keep it safe"

@app.route("/")
def index():
     mysql = connectToMySQL("survey")
     user = mysql.query_db("SELECT * FROM users;")
     print(user)
     return render_template("index.html")

@app.route("/process", methods=["POST"])
def process():
     is_valid = True  # assume True
     if len(request.form["name"]) < 1:
          is_valid = False
          flash("Please enter full name")

     if not is_valid:
          return redirect("/")
     else: 
          flash("You're successfully added!")
          
     mysql = connectToMySQL("survey")
     query = "INSERT INTO users(name, location, language, created_at, updated_at) VALUES (%(na)s, %(lo)s, %(la)s, NOW(), NOW())"
     data = {
          "na": request.form["name"],
          "lo": request.form["location"],
          "la": request.form["language"],
     }
     session["user_id"] = mysql.query_db(query,data)    
     return redirect("/result")
     
@app.route("/result")
def result():
     mysql = connectToMySQL("survey")
     query = "SELECT * FROM users WHERE id=%(id)s;"
     data = {
          "id": session["user_id"]
     }
     user = mysql.query_db(query, data)
     print(user)
     return render_template("result.html", all_users = user)

if __name__ == "__main__":
     app.run(debug=True)