from flask import Flask, render_template, session, request, redirect
import random

app = Flask(__name__)
app.secret_key = "secret"

@app.route("/")
def index():
     session["number"] = random.randint(1, 100)
     print (session["number"])
     return render_template("index.html")

@app.route("/guess", methods=["POST"])
def result():
     if int(request.form["guess"]) == session["number"]:
          answer1 = "Correct!"
          return render_template("index.html", answer=answer1)     
     
     elif int(request.form["guess"]) < session["number"]:
          answer2 = "Too Low!"
          return render_template("index.html", answer=answer2)
     
     else:
          answer2 = "Too High!"
          return render_template("index.html", answer=answer2)

if __name__ == "__main__":
     app.run(debug=True)