from flask import Flask, render_template
app = Flask(__name__)

@app.route("/")
def hello():
     return render_template("index.html", xtimes= 8, ytimes=8)

@app.route("/<x>")
def x(x):
     return render_template("index.html", xtimes = int(x))

@app.route("/<x>/<y>")
def board(x, y):
     return render_template("index.html", xtimes = int(x), ytimes = int(y))



if __name__ == "__main__":
     app.run(debug=True)