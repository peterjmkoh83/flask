from flask import Flask, render_template, redirect, session, request
import random

app = Flask(__name__)
app.secret_key = "safe"

@app.route("/")
def index():
     
     if not "total_gold" in session:
          session["total_gold"] = 0
     else: 
          session["total_gold"] = session["total_gold"]
     return render_template("index.html")

@app.route("/process_money/farm", methods=["POST"])
def process_money_farm():
     session["total_gold"] += random.randint(10, 20)   
     return redirect("/")

@app.route("/process_money/cave", methods=["POST"])
def process_money_cave():
     session["total_gold"] += random.randint(5, 10)
     return redirect("/")

@app.route("/process_money/house", methods=["POST"])
def process_money_house():
     session["total_gold"] += random.randint(2, 5)   
     return redirect("/")

@app.route("/process_money/casino", methods=["POST"])
def process_money_casino():
     session["total_gold"] += random.randint(-50, 50)
     return redirect("/")

@app.route("/reset")
def reset():
     session.clear()
     return redirect("/")

if __name__ == "__main__":
     app.run(debug=True)