from flask import Flask, render_template, request, redirect
app = Flask(__name__)  

@app.route('/')         
def index():
    return render_template("index.html")

@app.route('/checkout', methods=['POST'])         
def checkout():
    print(request.form)
    blueberry_from_index = request.form['blueberry']
    strawberry_from_index = request.form['strawberry']
    rasberry_from_index = request.form['rasberry']
    apple_from_index = request.form['apple']
    firstname_from_index = request.form['first_name']
    lastname_from_index = request.form['last_name']
    studentid_from_index = request.form['student_id']
    count_fruit = int(request.form['blueberry']) + int(request.form['strawberry']) + int(request.form['rasberry']) + int(request.form['apple'])
    return render_template("checkout.html", blueberry_on_template=blueberry_from_index, strawberry_on_template=strawberry_from_index, rasberry_on_template=rasberry_from_index, apple_on_template=apple_from_index, firstname_on_template=firstname_from_index, lastname_on_template=lastname_from_index, studentid_on_template=studentid_from_index, count=count_fruit)

@app.route('/fruits')         
def fruits():
    return render_template("fruits.html")

if __name__=="__main__":   
    app.run(debug=True)    