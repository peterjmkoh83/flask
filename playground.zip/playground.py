from flask import Flask, render_template
app = Flask(__name__)

@app.route("/play")
def hello():
     return render_template("index.html", times=3) 

@app.route("/play/<x>/<color>")
def hello_2(x, color):
     return render_template("index.html", times=int(x), block_color=color)

if __name__ == "__main__":
     app.run(debug=True)

